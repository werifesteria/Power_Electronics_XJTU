Uout=zeros(1,400);
R=zeros(1,400);
power=zeros(1,400);
THD=zeros(1,400);
i=1;
 for r=0.1:0.5:200
        sim('Q2.slx');%%,[0,0.05]);
        Uout(1,i)=ud(end);
        THD(1,i)=thd(end);
        power(1,i)=pp(end);
        R(1,i)=r;
        i=i+1;
        clear ud thd p q;
 end
    figure(1); 
    plot(R,Uout)
    xlabel('R');
    ylabel('Ud');
    title('V0')

    figure(2); 
    plot(R,power)
    xlabel('R');
    ylabel('power');
    title('PF')
    axis([0.1,200,0,1])
    
    figure(3); 
    plot(R,THD)
    xlabel('R');
    ylabel('THD');
    title('THD')