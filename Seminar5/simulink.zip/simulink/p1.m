Uout = zeros(1,180); 
U1out = zeros(1,180); 
U3out = zeros(1,180); 
U5out = zeros(1,180); 
U7out = zeros(1,180); 
U4out = zeros(1,180); 
thd=zeros(1,180); 
i=1;
for a = 1:1:180
    sim('M1.slx') 
     Uout(i)=ans.Uo.Data(end);
     U1out(i)=ans.Uo1.Data(end);
     U3out(i)=ans.Uo3.Data(end);
     U4out(i)=ans.Uo4.Data(end);
     U5out(i)=ans.Uo5.Data(end);
     U7out(i)=ans.Uo7.Data(end);
     thd(i)=ans.THD.Data(end);
      fprintf('循环第%d轮\n',i);
      i=i+1;
end

alpha=1:1:180;
figure(1)
plot(alpha,Uout,'b-');
 xlabel('delay angle','fontname','times new roma');
 ylabel('RMS value of output voltage','fontname','times new roma');
  axis([0,180,0,inf]); 
figure(2)
plot(alpha,U1out,'b-');
hold on
plot(alpha,U3out,'b-');
plot(alpha,U5out,'b-');
plot(alpha,U7out,'b-');
 xlabel('delay angle','fontname','times new roma');
 ylabel('Harmonic Component of Output Voltage','fontname','times new roma');
  axis([0,180,0,inf]); 
figure(3)
plot(alpha,U3out,'b-');
 xlabel('delay angle','fontname','times new roma');
 ylabel('3rd Harmonic Component of Output Voltage','fontname','times new roma');
  axis([0,180,0,inf]); 
figure(4)
plot(alpha,U5out,'b-');
 xlabel('delay angle','fontname','times new roma');
 ylabel('5th Harmonic Component of Output Voltage','fontname','times new roma');
  axis([0,180,0,inf]); 
figure(5)
plot(alpha,U7out,'b-');
 xlabel('delay angle','fontname','times new roma');
 ylabel('7th Harmonic Component of Output Voltage','fontname','times new roma');
  axis([0,180,0,inf]); 
figure(6)
plot(alpha,U4out,'b-');
 xlabel('delay angle','fontname','times new roma');
 ylabel('4th Harmonic Component of Output Voltage','fontname','times new roma');
  axis([0,180,0,inf]); 
  figure(7)
plot(U1out,thd,'b-');
hold on
plot(Uo1,THDu,'b-');
 xlabel('U1out','fontname','times new roma');
 ylabel('THD','fontname','times new roma');
  axis([0,240,0,inf]); 
    figure(8)
  plot(U1out,thd,'b-');
hold on
plot(Uo1,THDu,'b-');
 xlabel('U1out','fontname','times new roma');
 ylabel('THD','fontname','times new roma');
  axis([0,240,0,inf]); 