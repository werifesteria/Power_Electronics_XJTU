U1 = zeros(1,360); 
U3 = zeros(1,360); 
U5 = zeros(1,360); 
U6 = zeros(1,360); 
U7= zeros(1,360); 
U9 = zeros(1,360); 
THD= zeros(1,360); 
phi=zeros(1,360);
i=1;
for a = 1:1:360 
sim('part01.slx') 
U1(i) = u1(2);
U3(i) = u3(2);
U5(i) = u5(2);
U6(i) = u6(2);
U7(i) = u7(2);
U9(i) = u9(2);
THD(i) = thd(2);
phi(i)=a;
i=i+1;
end
 figure(1); 
    plot(phi,U1,'LineWidth',2)
    xlabel('external phase angle');
    ylabel('fundamental component (RMS) of output voltage','fontname','times new roma');
  axis([0,360,0,inf]); 
   figure(2); 
    plot(phi,U3,'LineWidth',2)
    xlabel('external phase angle');
    ylabel('3th harmonic voltage','fontname','times new roma');
      axis([0,360,0,inf]); 
   figure(3); 
    plot(phi,U5,'LineWidth',2)
    xlabel('external phase angle','LineWidth',2);
    ylabel('5th harmonic voltage','fontname','times new roma');
  axis([0,360,0,inf]); 
      figure(4); 
    plot(phi,U6,'LineWidth',2)
    xlabel('external phase angle','LineWidth',2);
    ylabel('6th harmonic voltage','fontname','times new roma');
  axis([0,360,0,inf]); 
      figure(5); 
    plot(phi,U7,'LineWidth',2)
    xlabel('external phase angle');
    ylabel('7th harmonic voltage','fontname','times new roma');
      axis([0,360,0,inf]); 
      figure(6); 
    plot(phi,U9,'LineWidth',2)
    xlabel('external phase angle');
    ylabel('9th harmonic voltage','fontname','times new roma');
      axis([0,360,0,inf]); 
     figure(7); 
    plot(phi,THD)
    xlabel('external phase angle');
    ylabel('THD');
      axis([0,360,0,inf]); 