% clc;clear;
% N=99;k=1;
% Uo=zeros(1,N); %输出电压
% 
% tic %计时模块
% for D=1:1:99
%     out=sim('AC_chopper',[0,0.5]);
%     Uo(k)=out.Uo.Data(end);
%     fprintf('第%d轮\n',k);
%     k=k+1;
% end
% toc
% 
% d=1:1:99;
% figure(1)
% plot(d,Uo,'b-');
% xlabel('$D/\%$','Interpreter','latex');
% ylabel('$U_{o}/ \mathrm{V}$','Interpreter','latex');
% title('$U_{o}=f(D)$','Interpreter','latex');

%% 谐波分析
clc;clear;
N=99;k=1;
Uo1=zeros(1,N);
Uo19=zeros(1,N);
Uo21=zeros(1,N);
Uo39=zeros(1,N);
Uo41=zeros(1,N);
THDu=zeros(1,N);

tic %计时模块
for D=1:1:99
    out=sim('AC_chopper',[0,0.05]);
    Uo1(k)=out.Uo1.Data(end);
    Uo19(k)=out.Uo19.Data(end);
    Uo21(k)=out.Uo21.Data(end);
    Uo39(k)=out.Uo39.Data(end);
    Uo41(k)=out.Uo41.Data(end);
    THDu(k)=out.THDu.Data(end);
    fprintf('第%d轮\n',k);
    k=k+1;
end
toc

clf;

d=1:1:99;
figure(1)
plot(Uo1,THDu,'b-');
xlabel('$U_{o1}/ \mathrm{V}$','Interpreter','latex','fontname','times new roma');
ylabel('THDu','Interpreter','latex','fontname','times new roma');
title('THDu=f(Uo1)','Interpreter','latex','fontname','times new roma');

figure(2)
plot(d,Uo1,'k-');
hold on
plot(d,Uo21,'b-');
plot(d,Uo41,'m-');
xlabel('D/ \%','Interpreter','latex','fontname','times new roma');
ylabel('Harmonic Component of Output Voltage/$\mathrm{V}$','Interpreter','latex','fontname','times new roma'); 
legend('1st','19th and 21st','39th and 41st','Interpreter','latex','fontname','times new roma');