
U1 = zeros(1,7); 
U3 = zeros(1,7); 
U5 = zeros(1,7); 
U6 = zeros(1,36); 
U7= zeros(1,36); 
U9 = zeros(1,36); 
THD= zeros(1,36); 
phi=zeros(1,36);


i=1;
for a = 10:10:70
    sim('part01.slx') 
    U1(i)=u1(2);
    i=i+1;
end